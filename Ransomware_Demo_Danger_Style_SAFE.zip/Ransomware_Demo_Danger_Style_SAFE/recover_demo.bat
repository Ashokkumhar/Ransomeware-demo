@echo off
title SAFE RECOVERY DEMO
cd /d "%~dp0"
color 0A

echo ======================================================
echo   SAFE RECOVERY DEMO
echo ======================================================
echo.

python recover_demo_files.py

echo.
pause
