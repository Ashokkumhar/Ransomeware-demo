@echo off
title SAFE RANSOMWARE SIMULATION - DANGER STYLE
cd /d "%~dp0"
color 0C

echo ======================================================
echo   SAFE RANSOMWARE SIMULATION - DANGER STYLE
echo   CLASSROOM DEMO ONLY - NO REAL ENCRYPTION
echo ======================================================
echo.
echo Starting demo...
echo.

python safe_ransomware_demo.py

echo.
echo Demo Finished.
pause
