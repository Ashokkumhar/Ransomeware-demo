SAFE RANSOMWARE SIMULATION - DANGER STYLE

This package is for cybersecurity awareness classroom demo only.

IMPORTANT SAFETY POINTS
- This is NOT real ransomware.
- It does NOT encrypt files.
- It does NOT delete files.
- It does NOT connect to the internet.
- It does NOT create startup/persistence.
- It only renames demo files inside the Demo_Data folder with .locked.

FOLDER STRUCTURE

Ransomware_Demo_Danger_Style_SAFE/
├── safe_ransomware_demo.py
├── recover_demo_files.py
├── run_demo.bat
├── recover_demo.bat
├── README.txt
└── Demo_Data/
    ├── student.txt
    ├── fees.txt
    ├── project.txt
    ├── marksheet.txt
    └── important_notes.txt

HOW TO RUN

1. Install Python on Windows.
2. During Python installation, tick: Add Python to PATH.
3. Double-click run_demo.bat.
4. A warning popup, fake terminal animation, beep sound, and full-screen danger-style screen will appear.
5. Press ESC to close the full-screen demo screen.
6. Open Demo_Data folder to show files renamed to .locked.
7. Double-click recover_demo.bat to restore files.

CLASSROOM EXPLANATION POINTS

Explain:
- Phishing entry point
- File locking/encryption concept
- Fake ransom note
- Why backups are important
- EDR/antivirus detection
- Patch management
- Least privilege
- User awareness

SAFE DEMO LIMITATION

This demo intentionally avoids real encryption, destructive actions, persistence, privilege escalation, network spreading, and C2 communication.
