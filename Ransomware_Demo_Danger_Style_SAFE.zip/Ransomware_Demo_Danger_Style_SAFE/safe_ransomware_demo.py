import os
import time
import tkinter as tk
from tkinter import messagebox

# ============================================================
# SAFE RANSOMWARE SIMULATION - CLASSROOM DEMO ONLY
# ============================================================
# This is NOT real ransomware.
# It does NOT encrypt files.
# It does NOT delete files.
# It does NOT connect to the internet.
# It does NOT create startup/persistence.
# It only renames demo files inside Demo_Data to ".locked".
# ============================================================

folder = "Demo_Data"

RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RESET = "\033[0m"

def slow_print(text, delay=0.025):
    for char in text:
        print(char, end="", flush=True)
        time.sleep(delay)
    print()

# Create demo folder and sample files
os.makedirs(folder, exist_ok=True)

dummy_files = {
    "student.txt": "Student records demo data",
    "fees.txt": "Fees details demo data",
    "project.txt": "Project report demo data",
    "marksheet.txt": "Marks demo data",
    "important_notes.txt": "Important notes demo data"
}

for name, content in dummy_files.items():
    path = os.path.join(folder, name)
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

# Beep sound
try:
    import winsound
    for freq in [900, 1100, 900, 1300]:
        winsound.Beep(freq, 180)
        time.sleep(0.08)
except Exception:
    pass

# Dark warning popup
messagebox.showwarning(
    "SECURITY ALERT - SAFE DEMO",
    "WARNING!\n\nSuspicious activity detected.\nDemo files are being locked.\n\nThis is only a SAFE classroom simulation."
)

# Dramatic fake CMD animation
print(RED + "=" * 70 + RESET)
print(RED + "           SAFE RANSOMWARE SIMULATION - DANGER STYLE" + RESET)
print(RED + "=" * 70 + RESET)
print(YELLOW + "Mode: Classroom Awareness Demo | No real encryption" + RESET)
print()

steps = [
    "[+] Initializing simulated attack module...",
    "[*] Checking demo environment...",
    "[*] Scanning Demo_Data folder...",
    "[*] Finding documents, notes, reports...",
    "[*] Preparing fake lock routine...",
    "[*] Renaming demo files only...",
]

for step in steps:
    slow_print(RED + step + RESET, 0.015)
    time.sleep(0.35)

# Safe lock: only rename files in Demo_Data
locked_count = 0
for file in os.listdir(folder):
    file_path = os.path.join(folder, file)

    if os.path.isfile(file_path) and not file.endswith(".locked") and file != "READ_ME.txt":
        os.rename(file_path, file_path + ".locked")
        print(RED + f"[LOCKED] {os.path.abspath(file_path)} -> {file}.locked" + RESET)
        locked_count += 1
        time.sleep(0.35)

print()
slow_print(YELLOW + "[*] Creating fake ransom note..." + RESET, 0.015)
time.sleep(0.5)

# Fake ransom note
note = """YOUR FILES ARE LOCKED!

This is a SAFE CLASSROOM SIMULATION.
No real encryption has been performed.

What happened in this demo:
- Demo files were NOT encrypted
- Demo files were only renamed with .locked extension
- A fake ransom note was created

In real ransomware attacks:
- Files may be encrypted with strong cryptography
- Attackers may demand payment
- Malware may spread in networks
- Backups may be deleted or encrypted

Defense:
- Keep offline backups
- Do not open unknown email attachments
- Keep OS and software updated
- Use antivirus/EDR
- Apply least privilege
- Train users against phishing
"""

with open(os.path.join(folder, "READ_ME.txt"), "w", encoding="utf-8") as f:
    f.write(note)

print(GREEN + f"[+] Simulation completed successfully. Files locked: {locked_count}" + RESET)
print(GREEN + "[+] Open Demo_Data folder to see the result." + RESET)

# Fullscreen dramatic ransom message with countdown
def close_demo(event=None):
    root.destroy()

root = tk.Tk()
root.title("YOUR FILES ARE LOCKED - SAFE SIMULATION")
root.attributes("-fullscreen", True)
root.configure(bg="#050000")

# Top warning strip
strip = tk.Label(
    root,
    text="⚠ SAFE RANSOMWARE SIMULATION — EDUCATIONAL DEMO ONLY ⚠",
    fg="#ffcc00",
    bg="#3b0000",
    font=("Consolas", 20, "bold"),
    pady=10
)
strip.pack(fill="x")

main = tk.Frame(root, bg="#050000")
main.pack(expand=True, fill="both", padx=40, pady=30)

left = tk.Frame(main, bg="#050000")
left.pack(side="left", expand=True, fill="both")

right = tk.Frame(main, bg="#050000")
right.pack(side="right", expand=True, fill="both")

skull = tk.Label(
    left,
    text="☠",
    fg="#ff0000",
    bg="#050000",
    font=("Arial", 105, "bold")
)
skull.pack(pady=(20, 0))

title = tk.Label(
    left,
    text="YOUR FILES\nARE LOCKED!",
    fg="#ff1a1a",
    bg="#050000",
    font=("Impact", 58, "bold"),
    justify="center"
)
title.pack(pady=10)

subtitle = tk.Label(
    left,
    text="This is a SAFE classroom demo.\nNo real encryption has been performed.",
    fg="white",
    bg="#050000",
    font=("Arial", 23, "bold"),
    justify="center"
)
subtitle.pack(pady=10)

demo_mode = tk.Label(
    left,
    text="DEMO MODE: Files were only renamed to .locked",
    fg="#00ff66",
    bg="#050000",
    font=("Consolas", 20, "bold")
)
demo_mode.pack(pady=10)

box1 = tk.Label(
    right,
    text="WHAT HAPPENED?\n\nYour demo files were renamed.\nA fake ransom note was created.\nNothing was encrypted.",
    fg="white",
    bg="#160000",
    font=("Consolas", 18),
    justify="left",
    bd=2,
    relief="solid",
    padx=25,
    pady=20
)
box1.pack(fill="x", pady=15)

box2 = tk.Label(
    right,
    text="WHAT YOU SHOULD TEACH?\n\n• Phishing is a common entry point\n• Backups are critical\n• EDR/Antivirus can detect suspicious behavior\n• Least privilege reduces impact",
    fg="white",
    bg="#160000",
    font=("Consolas", 18),
    justify="left",
    bd=2,
    relief="solid",
    padx=25,
    pady=20
)
box2.pack(fill="x", pady=15)

timer_label = tk.Label(
    right,
    text="",
    fg="#ff1a1a",
    bg="#050000",
    font=("DS-Digital", 42, "bold")
)
timer_label.pack(pady=25)

bottom = tk.Label(
    root,
    text="Press ESC to exit  |  Run recover_demo.bat to restore demo files",
    fg="#cfcfcf",
    bg="#050000",
    font=("Consolas", 18),
    pady=15
)
bottom.pack(fill="x")

def countdown(seconds):
    if seconds >= 0:
        m, s = divmod(seconds, 60)
        timer_label.config(text=f"TIME REMAINING: {m:02d}:{s:02d}")
        root.after(1000, countdown, seconds - 1)
    else:
        timer_label.config(text="DEMO COMPLETED")

root.bind("<Escape>", close_demo)
countdown(45)
root.mainloop()

try:
    import winsound
    winsound.Beep(700, 250)
except Exception:
    pass

messagebox.showinfo(
    "Demo Finished",
    "Safe ransomware simulation completed.\nOpen Demo_Data folder to see the result.\nRun recover_demo.bat to restore files."
)

print("[+] Demo finished.")
input("Press Enter to close.")
