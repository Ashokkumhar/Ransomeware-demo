@echo off
title Recovery Demo
cd /d "%~dp0"

echo ==========================================
echo   RECOVERY DEMO
echo ==========================================
echo.

python recover_demo_files.py

echo.
pause
