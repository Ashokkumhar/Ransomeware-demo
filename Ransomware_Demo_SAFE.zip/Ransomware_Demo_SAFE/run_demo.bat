@echo off
title Safe Ransomware Demo
cd /d "%~dp0"

echo ==========================================
echo   SAFE RANSOMWARE SIMULATION
echo   NO REAL ENCRYPTION - CLASSROOM DEMO
echo ==========================================
echo.

python safe_ransomware_demo.py

echo.
echo Demo Finished.
pause
