# Safe Ransomware Simulation Demo

This package is for cybersecurity awareness classroom demo only.

## Important
- This is NOT real ransomware.
- It does NOT encrypt files.
- It does NOT connect to the internet.
- It does NOT create persistence.
- It only renames demo files inside the `Demo_Data` folder with `.locked`.

## Folder Structure

Ransomware_Demo_SAFE/
├── safe_ransomware_demo.py
├── recover_demo_files.py
├── run_demo.bat
├── recover_demo.bat
└── Demo_Data/
    ├── student.txt
    ├── fees.txt
    ├── project.txt
    └── marksheet.txt

## How to Run

1. Install Python on Windows.
2. During Python installation, tick: Add Python to PATH.
3. Double-click `run_demo.bat`.
4. Press ESC to close the fullscreen demo screen.
5. Open `Demo_Data` folder to show files renamed to `.locked`.
6. Double-click `recover_demo.bat` to restore files.

## Teaching Points

Explain:
- Phishing entry point
- File locking/encryption concept
- Ransom note
- Importance of backup
- EDR/antivirus
- Patch management
- Least privilege
- User awareness
