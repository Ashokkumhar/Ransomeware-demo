import os
import time
import tkinter as tk
from tkinter import messagebox

# SAFE CLASSROOM SIMULATION ONLY
# This script does NOT encrypt files.
# It only renames demo files inside Demo_Data to ".locked".

folder = "Demo_Data"

# Create demo folder and sample files
os.makedirs(folder, exist_ok=True)

dummy_files = {
    "student.txt": "Student records demo data",
    "fees.txt": "Fees details demo data",
    "project.txt": "Project report demo data",
    "marksheet.txt": "Marks demo data"
}

for name, content in dummy_files.items():
    path = os.path.join(folder, name)
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

# Beep sound
try:
    import winsound
    for _ in range(3):
        winsound.Beep(1000, 300)
        time.sleep(0.2)
except Exception:
    pass

# Fake warning popup
messagebox.showwarning(
    "Security Alert - Safe Demo",
    "Suspicious activity detected!\nDemo files are being locked...\n\nThis is only a safe classroom simulation."
)

# Fake CMD animation
print("=" * 55)
print(" SAFE RANSOMWARE SIMULATION - NO REAL ENCRYPTION")
print("=" * 55)

steps = [
    "Scanning demo folder...",
    "Finding dummy documents...",
    "Locking demo files by renaming only...",
    "Creating fake ransom note...",
    "Launching awareness screen..."
]

for step in steps:
    print("[*] " + step)
    time.sleep(1)

# Safe lock: only rename files in Demo_Data
for file in os.listdir(folder):
    file_path = os.path.join(folder, file)

    if os.path.isfile(file_path) and not file.endswith(".locked") and file != "READ_ME.txt":
        os.rename(file_path, file_path + ".locked")
        print(f"[LOCKED] {file} -> {file}.locked")
        time.sleep(0.4)

# Fake ransom note
note = """YOUR FILES ARE LOCKED!

This is a SAFE CLASSROOM SIMULATION.
No real encryption has been performed.

What happened in this demo:
- Files were NOT encrypted
- Files were only renamed with .locked extension
- A fake ransom note was created

In real ransomware attacks:
- Files may be encrypted with strong cryptography
- Attackers may demand payment
- Malware may spread in networks
- Backups may be targeted

Defense:
- Keep offline backups
- Do not open unknown attachments
- Keep OS and software updated
- Use antivirus/EDR
- Apply least privilege
- Train users against phishing
"""

with open(os.path.join(folder, "READ_ME.txt"), "w", encoding="utf-8") as f:
    f.write(note)

# Fullscreen fake ransom message with countdown
def close_demo():
    root.destroy()

root = tk.Tk()
root.title("Safe Ransomware Simulation")
root.attributes("-fullscreen", True)
root.configure(bg="black")

title = tk.Label(
    root,
    text="YOUR FILES ARE LOCKED",
    fg="red",
    bg="black",
    font=("Arial", 40, "bold")
)
title.pack(pady=40)

msg = tk.Label(
    root,
    text="SAFE CLASSROOM DEMO\n\nNo real encryption happened.\nYour demo files were only renamed to .locked",
    fg="white",
    bg="black",
    font=("Arial", 22)
)
msg.pack(pady=20)

timer_label = tk.Label(
    root,
    text="",
    fg="yellow",
    bg="black",
    font=("Arial", 28, "bold")
)
timer_label.pack(pady=30)

def countdown(seconds):
    if seconds >= 0:
        timer_label.config(text=f"Fake Countdown: {seconds} seconds")
        root.after(1000, countdown, seconds - 1)
    else:
        timer_label.config(text="Demo Completed. Press ESC to exit.")

root.bind("<Escape>", lambda e: close_demo())

info = tk.Label(
    root,
    text="Press ESC to exit demo screen",
    fg="gray",
    bg="black",
    font=("Arial", 16)
)
info.pack(side="bottom", pady=30)

countdown(30)
root.mainloop()

print("[+] Demo completed. Open Demo_Data folder.")
print("[+] Press Enter to close.")
input()
