import os

# Recovery for SAFE CLASSROOM SIMULATION
# Restores .locked demo files by removing the .locked extension.

folder = "Demo_Data"

print("[*] Starting recovery...")

if not os.path.exists(folder):
    print("Demo_Data folder not found.")
    input("Press Enter to close.")
    exit()

restored = 0

for file in os.listdir(folder):
    if file.endswith(".locked"):
        old_path = os.path.join(folder, file)
        new_path = os.path.join(folder, file.replace(".locked", ""))
        os.rename(old_path, new_path)
        print(f"[RESTORED] {file} -> {file.replace('.locked', '')}")
        restored += 1

note_path = os.path.join(folder, "READ_ME.txt")
if os.path.exists(note_path):
    os.remove(note_path)
    print("[REMOVED] READ_ME.txt")

print(f"[+] Recovery completed. Restored files: {restored}")
input("Press Enter to close.")
